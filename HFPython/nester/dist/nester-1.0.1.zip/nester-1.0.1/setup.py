from distutils.core import setup
setup(
	name = 'nester',
	version = '1.0.1',
	py_modules = ['nester_ch2'],
	author = 'Shaan',
	author_email = 'shanu.linkinpark@gmail.com',
	description = 'A simple printer of nested lists'
)
#use URL as well