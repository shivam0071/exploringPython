'''
A small module to print the list of list of lists
'''
def print_lol(the_list,indent=False,level = 0):
    '''
    The function prints each list element and if it encounters another list it calss itself untill it has an basic data type element
    '''
    for item_0 in the_list:
        if isinstance(item_0,list):
            print_lol(item_0,indent,level+1)

        else:
            if indent:
                for i in range(level):
                    print("\t",end="")

            print(item_0)
